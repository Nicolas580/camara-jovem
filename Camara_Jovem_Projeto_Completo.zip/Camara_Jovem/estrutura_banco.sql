-- Banco de dados do projeto Câmara Jovem
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    senha_hash TEXT NOT NULL,
    criado_em TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS propostas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    titulo TEXT NOT NULL,
    categoria TEXT NOT NULL,
    descricao TEXT NOT NULL,
    justificativa TEXT NOT NULL,
    autor_id INTEGER NOT NULL,
    criada_em TEXT NOT NULL,
    FOREIGN KEY (autor_id) REFERENCES usuarios(id)
);

CREATE TABLE IF NOT EXISTS votos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id INTEGER NOT NULL,
    proposta_id INTEGER NOT NULL,
    voto TEXT NOT NULL CHECK(voto IN ('A favor', 'Contra')),
    votado_em TEXT NOT NULL,
    UNIQUE(usuario_id, proposta_id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (proposta_id) REFERENCES propostas(id)
);
