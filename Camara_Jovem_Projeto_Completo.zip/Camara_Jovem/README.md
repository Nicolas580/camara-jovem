# Câmara Jovem

Sistema escolar de cadastro de usuários, cadastro de propostas de leis e votação.

## Tecnologias
- Python
- Streamlit
- SQLite 3

## Como executar

1. Instale o Python 3.10 ou superior.
2. Abra o terminal na pasta do projeto.
3. Instale a dependência:

   ```bash
   pip install -r requirements.txt
   ```

4. Inicie o site:

   ```bash
   streamlit run app.py
   ```

5. O navegador abrirá o sistema. Se não abrir automaticamente, acesse o endereço mostrado no terminal (normalmente http://localhost:8501).

## Funcionalidades
- Cadastro e login de usuários.
- Senhas armazenadas com hash e salt.
- Cadastro de propostas com categoria, descrição e justificativa.
- Votação a favor ou contra.
- Restrição de um voto por usuário em cada proposta.
- Painel com indicadores e resultados.
- Perfil com propostas e votos do usuário.
- Banco SQLite criado automaticamente na primeira execução.

## Banco de dados
O arquivo `camara_jovem.db` é criado automaticamente na pasta do projeto quando o sistema é executado pela primeira vez.

Tabelas:
- `usuarios`: dados das contas.
- `propostas`: propostas cadastradas.
- `votos`: votos registrados, com restrição de voto único por usuário/proposta.

## Observação
Este é um projeto educacional para execução local e demonstração em sala. Para publicar na internet e utilizar com dados reais, seriam necessárias medidas adicionais de segurança, hospedagem e administração.
