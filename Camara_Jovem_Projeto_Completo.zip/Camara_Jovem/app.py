import streamlit as st
import sqlite3
import hashlib
import hmac
import secrets
from datetime import datetime

DB_NAME = "camara_jovem.db"

# ------------------------- CONFIGURAÇÃO -------------------------
st.set_page_config(
    page_title="Câmara Jovem",
    page_icon="🏛️",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap');
    html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
    .stApp { background: #f4f7fb; }
    [data-testid="stSidebar"] { background: #10243a; }
    [data-testid="stSidebar"] * { color: #f4f7fb !important; }
    .hero {
        background: linear-gradient(120deg, #10243a 0%, #174b61 65%, #16866f 100%);
        padding: 30px 34px; border-radius: 18px; color: white; margin-bottom: 22px;
    }
    .hero h1 { color: white; font-size: 2.25rem; margin: 0 0 8px 0; }
    .hero p { color: #dceaf0; font-size: 1rem; margin: 0; }
    .metric-card {
        background: white; padding: 20px; border-radius: 15px;
        border: 1px solid #e6edf3; box-shadow: 0 3px 12px rgba(16,36,58,.04);
    }
    .metric-label { color: #627386; font-size: .9rem; margin-bottom: 6px; }
    .metric-value { color: #10243a; font-size: 2rem; font-weight: 800; }
    .proposal-card {
        background: white; padding: 20px; border-radius: 15px;
        border: 1px solid #e6edf3; margin-bottom: 13px;
    }
    .small-muted { color: #6c7c8c; font-size: .86rem; }
    div.stButton > button {
        border-radius: 10px; font-weight: 700; min-height: 42px;
    }
    .section-title { color: #10243a; font-weight: 800; margin-top: 10px; }
    .tag {
        display: inline-block; background: #e7f4f0; color: #16745f;
        padding: 4px 10px; border-radius: 20px; font-size: .78rem; font-weight: 700;
    }
</style>
""", unsafe_allow_html=True)


# ------------------------- BANCO DE DADOS -------------------------
def conectar():
    conn = sqlite3.connect(DB_NAME, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def criar_banco():
    with conectar() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                senha_hash TEXT NOT NULL,
                criado_em TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS propostas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                titulo TEXT NOT NULL,
                categoria TEXT NOT NULL,
                descricao TEXT NOT NULL,
                justificativa TEXT NOT NULL,
                autor_id INTEGER NOT NULL,
                criada_em TEXT NOT NULL,
                FOREIGN KEY (autor_id) REFERENCES usuarios(id)
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS votos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario_id INTEGER NOT NULL,
                proposta_id INTEGER NOT NULL,
                voto TEXT NOT NULL CHECK(voto IN ('A favor', 'Contra')),
                votado_em TEXT NOT NULL,
                UNIQUE(usuario_id, proposta_id),
                FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
                FOREIGN KEY (proposta_id) REFERENCES propostas(id)
            )
        """)


def gerar_hash(senha, salt=None):
    salt = salt or secrets.token_bytes(16)
    derivado = hashlib.pbkdf2_hmac("sha256", senha.encode("utf-8"), salt, 200_000)
    return salt.hex() + ":" + derivado.hex()


def conferir_senha(senha, armazenada):
    try:
        salt_hex, hash_hex = armazenada.split(":")
        salt = bytes.fromhex(salt_hex)
        calculado = hashlib.pbkdf2_hmac("sha256", senha.encode("utf-8"), salt, 200_000).hex()
        return hmac.compare_digest(calculado, hash_hex)
    except (ValueError, TypeError):
        return False


def buscar_usuario(email):
    with conectar() as conn:
        return conn.execute(
            "SELECT * FROM usuarios WHERE email = ?", (email.strip(),)
        ).fetchone()


def cadastrar_usuario(nome, email, senha):
    with conectar() as conn:
        conn.execute(
            "INSERT INTO usuarios (nome, email, senha_hash, criado_em) VALUES (?, ?, ?, ?)",
            (nome.strip(), email.strip().lower(), gerar_hash(senha),
             datetime.now().strftime("%d/%m/%Y %H:%M"))
        )


def listar_propostas():
    with conectar() as conn:
        return conn.execute("""
            SELECT p.*, u.nome AS autor,
                   SUM(CASE WHEN v.voto = 'A favor' THEN 1 ELSE 0 END) AS favor,
                   SUM(CASE WHEN v.voto = 'Contra' THEN 1 ELSE 0 END) AS contra,
                   COUNT(v.id) AS total
            FROM propostas p
            JOIN usuarios u ON u.id = p.autor_id
            LEFT JOIN votos v ON v.proposta_id = p.id
            GROUP BY p.id
            ORDER BY p.id DESC
        """).fetchall()


def obter_voto(usuario_id, proposta_id):
    with conectar() as conn:
        return conn.execute(
            "SELECT voto FROM votos WHERE usuario_id = ? AND proposta_id = ?",
            (usuario_id, proposta_id)
        ).fetchone()


def registrar_voto(usuario_id, proposta_id, voto):
    with conectar() as conn:
        conn.execute(
            "INSERT INTO votos (usuario_id, proposta_id, voto, votado_em) VALUES (?, ?, ?, ?)",
            (usuario_id, proposta_id, voto, datetime.now().strftime("%d/%m/%Y %H:%M"))
        )


def minhas_propostas(usuario_id):
    with conectar() as conn:
        return conn.execute("""
            SELECT p.*,
                   SUM(CASE WHEN v.voto = 'A favor' THEN 1 ELSE 0 END) AS favor,
                   SUM(CASE WHEN v.voto = 'Contra' THEN 1 ELSE 0 END) AS contra,
                   COUNT(v.id) AS total
            FROM propostas p
            LEFT JOIN votos v ON v.proposta_id = p.id
            WHERE p.autor_id = ?
            GROUP BY p.id
            ORDER BY p.id DESC
        """, (usuario_id,)).fetchall()


criar_banco()


# ------------------------- FUNÇÕES VISUAIS -------------------------
def mostrar_cabecalho(titulo, subtitulo):
    st.markdown(
        f'<div class="hero"><h1>{titulo}</h1><p>{subtitulo}</p></div>',
        unsafe_allow_html=True
    )


def metricas():
    propostas = listar_propostas()
    with conectar() as conn:
        usuarios = conn.execute("SELECT COUNT(*) FROM usuarios").fetchone()[0]
        votos = conn.execute("SELECT COUNT(*) FROM votos").fetchone()[0]
    c1, c2, c3 = st.columns(3)
    for col, label, valor in [
        (c1, "Usuários cadastrados", usuarios),
        (c2, "Propostas apresentadas", len(propostas)),
        (c3, "Votos registrados", votos)
    ]:
        with col:
            st.markdown(
                f'<div class="metric-card"><div class="metric-label">{label}</div>'
                f'<div class="metric-value">{valor}</div></div>',
                unsafe_allow_html=True
            )


def percentual(favor, contra):
    total = favor + contra
    return (favor / total * 100) if total else 0


# ------------------------- AUTENTICAÇÃO -------------------------
if "usuario" not in st.session_state:
    st.session_state.usuario = None

if st.session_state.usuario is None:
    st.sidebar.markdown("## 🏛️ Câmara Jovem")
    st.sidebar.caption("Participação, ideias e cidadania.")
    st.sidebar.markdown("---")
    st.sidebar.info("Entre na sua conta ou crie um cadastro para participar das votações.")

    mostrar_cabecalho(
        "Câmara Jovem",
        "Um espaço escolar para apresentar ideias, discutir propostas e participar de votações."
    )
    st.markdown("### Bem-vindo(a)!")
    st.write("Acompanhe propostas de leis, apresente suas próprias ideias e registre seu voto.")
    tab_login, tab_cadastro = st.tabs(["🔐 Entrar", "📝 Criar conta"])

    with tab_login:
        st.subheader("Acesse sua conta")
        with st.form("form_login"):
            email_login = st.text_input("E-mail", placeholder="seuemail@exemplo.com")
            senha_login = st.text_input("Senha", type="password")
            entrar = st.form_submit_button("Entrar", use_container_width=True)
        if entrar:
            usuario = buscar_usuario(email_login)
            if usuario and conferir_senha(senha_login, usuario["senha_hash"]):
                st.session_state.usuario = {
                    "id": usuario["id"], "nome": usuario["nome"], "email": usuario["email"]
                }
                st.rerun()
            else:
                st.error("E-mail ou senha incorretos.")

    with tab_cadastro:
        st.subheader("Crie seu cadastro")
        with st.form("form_cadastro"):
            nome = st.text_input("Nome completo")
            email = st.text_input("E-mail")
            senha = st.text_input("Crie uma senha", type="password")
            confirmar = st.text_input("Confirme a senha", type="password")
            cadastrar = st.form_submit_button("Cadastrar", use_container_width=True)
        if cadastrar:
            if not nome.strip() or not email.strip() or not senha:
                st.warning("Preencha todos os campos.")
            elif "@" not in email or "." not in email.split("@")[-1]:
                st.warning("Digite um e-mail válido.")
            elif len(senha) < 6:
                st.warning("A senha deve ter pelo menos 6 caracteres.")
            elif senha != confirmar:
                st.error("As senhas não são iguais.")
            else:
                try:
                    cadastrar_usuario(nome, email, senha)
                    st.success("Cadastro realizado! Agora entre usando seu e-mail e senha.")
                except sqlite3.IntegrityError:
                    st.error("Este e-mail já está cadastrado.")

    st.stop()


# ------------------------- ÁREA LOGADA -------------------------
usuario = st.session_state.usuario
st.sidebar.markdown("## 🏛️ Câmara Jovem")
st.sidebar.write(f"Olá, **{usuario['nome'].split()[0]}**!")
st.sidebar.markdown("---")
pagina = st.sidebar.radio(
    "NAVEGAÇÃO",
    ["🏠 Painel inicial", "📜 Propostas de leis", "➕ Nova proposta", "🗳️ Votação", "📊 Resultados", "👤 Meu perfil"]
)
st.sidebar.markdown("---")
if st.sidebar.button("Sair da conta", use_container_width=True):
    st.session_state.usuario = None
    st.rerun()
st.sidebar.caption("Projeto escolar • 2º D e 2º E")


if pagina == "🏠 Painel inicial":
    mostrar_cabecalho("Painel inicial", "Acompanhe a participação da comunidade Câmara Jovem.")
    metricas()
    st.markdown("### Como funciona?")
    a, b, c = st.columns(3)
    with a:
        st.markdown("#### 1. 💡 Apresente")
        st.write("Cadastre uma proposta com título, categoria, descrição e justificativa.")
    with b:
        st.markdown("#### 2. 🗳️ Participe")
        st.write("Leia as propostas disponíveis e escolha votar a favor ou contra.")
    with c:
        st.markdown("#### 3. 📊 Acompanhe")
        st.write("Consulte os resultados e veja a participação dos usuários.")
    st.markdown("### Propostas recentes")
    recentes = listar_propostas()[:3]
    if not recentes:
        st.info("Ainda não há propostas. Que tal cadastrar a primeira?")
    for p in recentes:
        with st.container(border=True):
            st.markdown(f"**{p['titulo']}**")
            st.caption(f"{p['categoria']} • Proposta de {p['autor']}")
            st.write(p["descricao"][:220] + ("..." if len(p["descricao"]) > 220 else ""))


elif pagina == "📜 Propostas de leis":
    mostrar_cabecalho("Propostas de leis", "Conheça as ideias cadastradas pelos participantes.")
    propostas = listar_propostas()
    if not propostas:
        st.info("Nenhuma proposta cadastrada até o momento.")
    for p in propostas:
        with st.container(border=True):
            st.markdown(f"### {p['titulo']}")
            st.markdown(f'<span class="tag">{p["categoria"]}</span>', unsafe_allow_html=True)
            st.caption(f"Autor: {p['autor']} • Enviada em {p['criada_em']}")
            st.write(p["descricao"])
            st.markdown("**Justificativa**")
            st.write(p["justificativa"])
            st.caption(f"🟢 A favor: {p['favor'] or 0}  |  🔴 Contra: {p['contra'] or 0}  |  Total: {p['total'] or 0}")


elif pagina == "➕ Nova proposta":
    mostrar_cabecalho("Nova proposta", "Sua ideia pode iniciar uma conversa e incentivar a participação.")
    with st.form("form_proposta", clear_on_submit=True):
        titulo = st.text_input("Título da proposta", max_chars=100)
        categoria = st.selectbox(
            "Categoria",
            ["Educação", "Meio ambiente", "Saúde", "Tecnologia", "Mobilidade", "Cultura e esporte", "Outra"]
        )
        descricao = st.text_area("Descrição da proposta", height=130,
                                 placeholder="Explique o que a proposta pretende estabelecer.")
        justificativa = st.text_area("Justificativa", height=110,
                                     placeholder="Explique por que essa proposta é importante.")
        enviar = st.form_submit_button("Publicar proposta", use_container_width=True)
    if enviar:
        if len(titulo.strip()) < 5 or len(descricao.strip()) < 20 or len(justificativa.strip()) < 20:
            st.warning("Use um título com pelo menos 5 caracteres e textos com pelo menos 20 caracteres.")
        else:
            with conectar() as conn:
                conn.execute("""
                    INSERT INTO propostas (titulo, categoria, descricao, justificativa, autor_id, criada_em)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (titulo.strip(), categoria, descricao.strip(), justificativa.strip(),
                      usuario["id"], datetime.now().strftime("%d/%m/%Y %H:%M")))
            st.success("Proposta publicada com sucesso!")
            st.rerun()


elif pagina == "🗳️ Votação":
    mostrar_cabecalho("Votação", "Leia cada proposta e registre sua opinião.")
    propostas = listar_propostas()
    disponiveis = [p for p in propostas if obter_voto(usuario["id"], p["id"]) is None]
    if not propostas:
        st.info("Ainda não existem propostas para votar.")
    elif not disponiveis:
        st.success("Você já votou em todas as propostas cadastradas. Obrigado por participar!")
    for p in disponiveis:
        with st.container(border=True):
            st.markdown(f"### {p['titulo']}")
            st.caption(f"{p['categoria']} • Autor: {p['autor']}")
            st.write(p["descricao"])
            st.markdown("**Justificativa:**")
            st.write(p["justificativa"])
            with st.form(f"voto_{p['id']}"):
                escolha = st.radio(
                    "Qual é o seu voto?",
                    ["A favor", "Contra"],
                    horizontal=True,
                    key=f"escolha_{p['id']}"
                )
                confirmar_voto = st.form_submit_button("Confirmar meu voto")
            if confirmar_voto:
                try:
                    registrar_voto(usuario["id"], p["id"], escolha)
                    st.success("Voto registrado! Cada usuário pode votar uma única vez em cada proposta.")
                    st.rerun()
                except sqlite3.IntegrityError:
                    st.warning("Seu voto para esta proposta já foi registrado.")


elif pagina == "📊 Resultados":
    mostrar_cabecalho("Resultados", "Confira a quantidade e a porcentagem dos votos.")
    propostas = listar_propostas()
    if not propostas:
        st.info("Os resultados aparecerão quando houver propostas e votos.")
    for p in propostas:
        favor = p["favor"] or 0
        contra = p["contra"] or 0
        total = p["total"] or 0
        aprovacao = percentual(favor, contra)
        with st.container(border=True):
            st.markdown(f"### {p['titulo']}")
            st.caption(f"{p['categoria']} • {total} voto(s)")
            x, y = st.columns(2)
            x.metric("🟢 A favor", favor)
            y.metric("🔴 Contra", contra)
            st.progress(int(aprovacao), text=f"{aprovacao:.1f}% de votos favoráveis")
            if total == 0:
                st.caption("Aguardando os primeiros votos.")
            elif favor > contra:
                st.caption("Resultado parcial: há mais votos favoráveis.")
            elif contra > favor:
                st.caption("Resultado parcial: há mais votos contrários.")
            else:
                st.caption("Resultado parcial: empate.")


elif pagina == "👤 Meu perfil":
    mostrar_cabecalho("Meu perfil", "Informações da sua conta e propostas cadastradas.")
    st.markdown(f"### {usuario['nome']}")
    st.write(f"**E-mail:** {usuario['email']}")
    minhas = minhas_propostas(usuario["id"])
    st.markdown("### Minhas propostas")
    if not minhas:
        st.info("Você ainda não cadastrou nenhuma proposta.")
    for p in minhas:
        with st.container(border=True):
            st.markdown(f"**{p['titulo']}**")
            st.caption(f"{p['categoria']} • {p['total'] or 0} voto(s)")
            st.write(p["descricao"])
    with conectar() as conn:
        total_votos = conn.execute(
            "SELECT COUNT(*) FROM votos WHERE usuario_id = ?", (usuario["id"],)
        ).fetchone()[0]
    st.metric("Votos registrados por você", total_votos)

st.markdown("---")
st.caption("Câmara Jovem • Projeto educacional de simulação de apresentação e votação de propostas.")
